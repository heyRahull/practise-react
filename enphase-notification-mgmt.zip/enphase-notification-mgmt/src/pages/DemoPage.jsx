import React from "react";

const DemoPage = () => {
  return <div>DemoPage</div>;
};

export default DemoPage;
