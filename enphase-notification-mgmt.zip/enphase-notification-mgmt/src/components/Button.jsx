import React from "react";

const Button = ({ children }) => {
  return (
    <button className="bg-orange-100 hover:bg-orange-500 border-2 border-orange-500 text-orange-500 hover:text-orange-100 font-bold py-2 px-4 rounded">
      {children}
    </button>
  );
};

export default Button;
