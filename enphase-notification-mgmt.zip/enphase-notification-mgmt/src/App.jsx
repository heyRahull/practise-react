import "./App.css";
import Button from "./components/Button";

function App() {
  return (
    <>
      <h1 className="text-4xl font-bold mb-4">Hello Enphase team</h1>

      <Button>Example Button</Button>
    </>
  );
}

export default App;
